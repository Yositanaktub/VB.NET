﻿Option Explicit Off
Public Class Form1

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Student_ID.Text = " 634272108"
        Student_Name.Text = " Yosita Naktub"
        Student_email.Text = "Yosita.nak@mail.pbru.ac.th"

        Dim birthdate As Date = #7/23/2002#
        REM Dim age As Integer

        age = Year(Today()) - Year(birthdate)
        dw = birthdate.DayOfWeek
        Student_age.Text = age.ToString & " เกิดวัน " & birthdate.ToString("dddd")
        Student_enroll.Text = (16000 * 8).ToString("฿#,###")
    End Sub
End Class
