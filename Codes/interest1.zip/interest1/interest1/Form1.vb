﻿Public Class Form1

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Dim interest1 As Double
        Double.TryParse(interest.Text, interest1)

        Dim deposit1 As Double
        Double.TryParse(deposit.Text, deposit1)

        Dim message As String = ""
        Dim newinterest As Double = 0
        For yy = 1 To 10
            newinterest = deposit1 * interest1 / 100
            message = message & "Year :" & yy & "  " & deposit1.ToString() & "  " & newinterest & vbNewLine


            deposit1 = deposit1 + newinterest
        Next
        detail.Text = message
    End Sub
End Class
